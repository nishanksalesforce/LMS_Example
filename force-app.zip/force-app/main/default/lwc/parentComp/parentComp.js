import { LightningElement } from 'lwc';
export default class ParentComp extends LightningElement {

}